# Instalação do Servidor de Segurança mctest-validator

*Criado por Gabriel Tavares Frota de Azevedo para o TCC do BCC/UFABC.*

Este repositório contém o script de instalação para o servidor de segurança `mctest-validator`, desenvolvido por Gabriel Tavares Frota de Azevedo como parte do Trabalho de Conclusão de Curso (TCC) do curso de Bacharelado em Ciência da Computação (BCC) da Universidade Federal do ABC (UFABC). O objetivo do servidor é rodar código de questões paramétricas no contexto do projeto MCTest.

## Requisitos do Sistema
Este guia é destinado para servidores Linux, onde o script será executado diretamente no servidor do MCTest.

## Passo a Passo para Instalação

1. **Instalar o Bandit** (para análise de segurança de código Python):
   ```bash
   pip install bandit
   ```

2. **Instalar Go**:
   Baixar e extrair o Go (versão 1.23.3) para o diretório `/usr/local`.
   ```bash
   wget https://golang.org/dl/go1.23.3.linux-amd64.tar.gz
   sudo tar -C /usr/local -xzf go1.23.3.linux-amd64.tar.gz
   ```

3. **Configurar a Variável de Ambiente PATH**:
   Adicionar o diretório do Go ao `PATH` no arquivo `~/.bashrc`.
   ```bash
   sudo sed -i '$ a export PATH=$PATH:/usr/local/go/bin' ~/.bashrc
   source ~/.bashrc
   ```

4. **Clonar o Repositório e Instalar Dependências**:
   Clonar o repositório `mctest-validator-api` e resolver as dependências com o comando `go mod tidy`.
   ```bash
   git clone https://github.com/leirbagseravat/mctest-validator-api.git
   cd mctest-validator-api
   go mod tidy
   ```

5. **Executar o Servidor**:
   Para executar o servidor em segundo plano e redirecionar o log para um arquivo:
   ```bash
   go run main.go > logfile.txt 2>&1 &
   ```

## Configuração de URL para Outros Servidores

Caso utilize outro servidor, altere a variável `url` no arquivo `UtilsMCTest4.py` para refletir o novo endereço:
```python
url = f'http://localhost:8080/mctest/validator/question/{pk}'
```

Certifique-se de que a **porta 8080** esteja liberada. Caso precise usar outra porta, ajuste-a no arquivo `mctest-validator-api/internal/http/app.go`:
```go
r.Run(":8080")
```

## Comando Útil para Verificar Processos na Porta
Para verificar se a porta 8001 (ou outra especificada) está ocupada:
```bash
sudo lsof -i :8001
```

---

Este guia cobre os passos básicos para instalar e configurar o servidor `mctest-validator` no Linux.
