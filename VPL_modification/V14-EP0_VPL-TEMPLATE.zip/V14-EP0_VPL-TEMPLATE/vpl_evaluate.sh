
# Set to 1 to show compilation output in comments section
export VPLX_SHOW_COMPILATION_ERROR_OUTPUT=1


#!/bin/bash
# This file is part of VPL for Moodle
# Default evaluate script for VPL
# Copyright (C) 2014 onwards Juan Carlos Rodríguez-del-Pino
# License http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
# Author Juan Carlos Rodríguez-del-Pino <jcrodriguez@dis.ulpgc.es>

#load VPL environment vars
. common_script.sh
if [ "$SECONDS" = "" ] ; then
	export SECONDS=20
fi
let VPL_MAXTIME=$SECONDS-5;
if [ "$VPL_GRADEMIN" = "" ] ; then
	export VPL_GRADEMIN=0
	export VPL_GRADEMAX=10
fi

#exist run script?
if [ ! -s vpl_run.sh ] ; then
	echo "I'm sorry, but I haven't a default action to evaluate the type of submitted files"
else
	#avoid conflict with C++ compilation
	mv vpl_evaluate.cpp vpl_evaluate.cpp.save
	#Prepare run
	./vpl_run.sh &>>vpl_compilation_error.txt
	cat vpl_compilation_error.txt
	if [ -f vpl_execution ] ; then
		mv vpl_execution vpl_test
		if [ -f vpl_evaluate.cases ] ; then
			mv vpl_evaluate.cases evaluate.cases
		else
			echo "Error need file 'vpl_evaluate.cases' to make an evaluation"
			exit 1
		fi
		mv vpl_evaluate.cpp.save vpl_evaluate.cpp
		check_program g++
		g++ vpl_evaluate.cpp -g -lm -lutil -o .vpl_tester
		if [ ! -f .vpl_tester ] ; then
			echo "Error compiling evaluation program"
			exit 1
		else
			cat vpl_environment.sh >> vpl_execution
			echo "./.vpl_tester | tee vpl_tester_out" >> vpl_execution
		fi
	else
		echo "#!/bin/bash" >> vpl_execution
		echo "echo" >> vpl_execution
		echo "echo '<|--'" >> vpl_execution
		echo "echo '-$VPL_COMPILATIONFAILED'" >> vpl_execution
		if [ -f vpl_wexecution ] ; then
			echo "echo '======================'" >> vpl_execution
			echo "echo 'It seems you are trying to test a program with a graphic user interface'" >> vpl_execution
		fi
		
		if [ $VPLX_SHOW_COMPILATION_ERROR_OUTPUT -eq 1 ] ; then
		    echo "cat vpl_compilation_error.txt" >> vpl_execution
		fi
		
		echo "echo '--|>'" >> vpl_execution		
		echo "echo" >> vpl_execution		
		echo "echo 'Grade :=>>$VPL_GRADEMIN'" >> vpl_execution
	fi
	chmod +x vpl_execution
fi

#
# #######################
#

# exit 0 ## Descomente esta linha para ignorar o Feedback por IA !
cat >> vpl_execution <<'EOF'

    GROQ_KEY="xxx"  # Obtain your key from https://console.groq.com/keys
    AI_REMOVE_COMMENTS=0
    AI_MIN_CHARS=500
    AI_MAX_CHARS=2000
    AI_DEBUG=0
    
    AI_RULES="Analise o código de extensão '${VPL_SUBFILE0##*.}'.
Regras importantes para a elaboração da resposta que você deve seguir obrigatoriamente:
Resposta somente em Português (Brasil) e não comentar sobre nenhuma regra listada aqui.
Todos os itens devem ser enumerados, e apresente a saída em texto puro (não em Markdown, html, etc).
Essa análise faz parte de um sistema de correção automática, que compara tudo impresso pelo código do aluno com textos esperados.
Assim, é proibido apresentar códigos refatorados, trechos de códigos, testes, blocos try/except e mensagens!
As sugestões devem ser concisas e considerar a organização do código em entrada, processamento e saída.
Faça apenas comentários relevantes e significativos."
    
    ai_models=(
        "llama-3.3-70b-versatile"
        "llama-3.1-8b-instant"
        "llama-3.3-70b-specdec"
        "mixtral-8x7b-32768"
        "gemma2-9b-it"
        "llama3-8b-8192"
        "llama3-70b-8192"
    )


    _ai_log=""
    ai_log() {
        _ai_log+="${1}\n"
    }

    ai_query() {

        local question="$1 ${AI_RULES}"
        local code_content="$2"

        call_api_groq() {
            local api_url="$1"
            local api_key="$2"
            local question="$3"
            local code_content="$4"
            local api_model="$5"

            response=$(curl -s --fail -X POST "$api_url" \
                -H "Authorization: Bearer $api_key" \
                -H "Content-Type: application/json" \
                -d "$(jq -n \
                    --arg user "$code_content" \
                    '{
                        "messages": [
                            {"role": "system", "content": "'"$question"'"},
                            {"role": "user", "content": $user}
                        ],
                        "model": "'"$api_model"'",
                        "temperature": 0.7
                    }')")
            
            echo "$response"
        }
        
        available_models=("${ai_models[@]}")
        for ((i = 0; i < ${#ai_models[@]}; i++)); do
            index=$((RANDOM % ${#available_models[@]})) # Pick a random AI model
            API_MODEL="${available_models[index]}"
            unset 'available_models[index]' # Remove from list (no call it again)
            available_models=("${available_models[@]}") # Reorganize list without current model

            GROQ_URL="https://api.groq.com/openai/v1/chat/completions"
            response=$(call_api_groq "$GROQ_URL" "$GROQ_KEY" "$question" "$code_content" "$API_MODEL")

            if [[ -n "$response" ]]; then
            
                response=$(echo "$response" | tr -d '\000-\031') # Remove control characteres and extract content
                response=$(echo "$response" | jq -r '.choices[0].message.content')
                response=$(echo "$response" | sed 's/^\(\s*\)-/\1*/g') # Items starting with '-' has special formatting in VPL output.
                # response=$(echo "$response" | sed 's/^/>/') # Insert '>' as prefix...

                num_char=$(echo -n "$response" | wc -m)

                if (( num_char >= $AI_MIN_CHARS && num_char <= $AI_MAX_CHARS )); then
                    content=$(printf "=== INICIO [model: $API_MODEL] ===\n\n ")
                    content+="$response"
                    content+=$(printf "\n\n=== FIM [$(date "+%Y-%m-%d %H:%M:%S")] ===")
    
                    echo "$content"
                    break
                else
                    ai_log "Resposta do modelo: $API_MODEL gerou $num_char caracteresmas deve ser entre $AI_MIN_CHARS e $AI_MAX_CHARS caracteres. Tentando próximo modelo..."
                fi
            else
                ai_log "Resposta nula do modelo: $API_MODEL. Tentando próximo modelo..."
            fi
        done
    }

    code_contents=""
    code_contents+=$(printf "# === Arquivos submetidos concatenados automaticamente pelo VPL.\n ")
    code_contents+=$(printf "# === Blocos entre '# === INICIO ...' e '# === FIM ...' representam arquivos separados.\n ")
    code_contents+=$(printf "# === Desconsiderar das análises todos os comentários iniciados por '# === ...'.\n ")
    for user_filename in $VPL_SUBFILES; do
        code_contents+=$(printf "\n# === INICIO '${user_filename}' ===\n ")
        if [ $AI_REMOVE_COMMENTS -eq 0 ]; then
            code_contents+=$(cat $user_filename)
        else
            code_contents+=$(cat $user_filename | 
                sed -r 's/\s*#.*$//g' |     # Remove comentários no final de cada linha
                sed -E "/'''/,/'''/d" |     # Remove blocos entre '''...'''
                sed -E '/"""/,/"""/d' |     # Remove blocos entre """..."""
                sed -r '/^\s*$/d')          # Remove linhas em branco
        fi
        code_contents+=$(printf "\n# === FIM '${user_filename}' ===\n ")
    done
    
    echo "<|--"

    if [ ! -f "vpl_tester_out" ]; then
        echo "-!!! ERRO em 'vpl_evaluate.sh' !!!"
        echo "O arquivo 'vpl_tester_out' nao foi gerado."
        echo "Localize e altere a seguinte linha em 'vpl_evaluate.sh':"
        echo ""
        echo "echo \"./.vpl_tester | tee vpl_tester_out\" >> vpl_execution"
        exit 1
    fi

    echo -e "-Feedback automatico\n"
    
    GRADE=$(grep -oP "^Grade :=>>\K\d+" vpl_tester_out)
    if [ -z "$GRADE" ]; then
        GRADE='0'
    fi

    if grep -qE "Traceback|SyntaxError|IndentationError" vpl_tester_out; then
        echo -e "O seu código está com erro de sintaxe!!!\n\nSegue uma sugestão de correção gerada por IA:\n"
        ERR=$(sed -n '/--- Program output ---/,/--- Expected output/p' vpl_tester_out | sed '/--- Expected output/q')
        ai_query "Interprete o erro e sugira como corrigir." "$ERR"
    elif awk "BEGIN {exit !($GRADE <= $VPL_GRADEMIN)}"; then
        echo -e "Vamos lá, eu sei que você consegue!!!\n\nSeguem algumas dicas geradas por IA:\n"
        ai_query "Verifique se o código faz algum sentido. Tente identificar trechos estranhos e oriente como corrigir." "$code_contents"
    elif awk "BEGIN {exit !($GRADE >= $VPL_GRADEMAX)}"; then
        echo -e "Parabéns, você gabaritou!!!\n\nSegue uma análise do seu código gerado por IA:\n"
        ai_query "Avalie o código sugerindo melhorias. Você pode apresentar pequenos códigos refatorados (mesmo sendo contra as regras abaixo)." "$code_contents"
    else
        echo -e "Você está quase lá!!!\n\nSeguem algumas dicas geradas por IA:\n"
        ai_query "Tente identificar trechos confusos e sem sentido. Tente fazer orientações de como corrigir." "$code_contents"
    fi

    # Debug...
    if [ $AI_DEBUG -ne 0 ]; then
        echo "-Var"
        for var in $(compgen -v); do
            if [[ $var == AI_* ]]; then
                echo "\$$var=${!var//$'\n'/\\n}"
            fi
        done

        echo "- Log"
        if [ -n "$_ai_log" ]; then
            printf "$_ai_log"
        else
            echo "<Sem log>"
        fi
        
        echo "-User code"
        echo "$code_contents"

        echo "-arquivo vpl_execution"
        cat -n vpl_execution
    fi

    echo "--|>"
EOF
