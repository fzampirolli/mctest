#!/bin/bash
. common_script.sh

function fail_abort {
	rm vpl_execution
	exit 0
}

### ATENCAO: este codigo funciona para submissoes com apenas 1 arquivo ###

filename=$(basename "$VPL_SUBFILE0")
FILE_EXT="${filename##*.}"

touch vpl_execution

export VPL_SUBFILE0="$VPL_SUBFILE0"
export FILE_EXT="${filename##*.}"

{
case $FILE_EXT in
	c)
		check_program gcc
		gcc -fno-diagnostics-color -o vpl_execution -std=c99 $VPL_SUBFILE0 -lm -lutil
		;;
	cpp|C)
		check_program g++
		g++ -fno-diagnostics-color -o vpl_execution $VPL_SUBFILE0 -lm -lutil
		;;
	java)
		function getClassName {
			#replace / for .
			local CLASSNAME=$(echo "$VPL_SUBFILE0" | sed 's/\//\./g')
			#remove file extension .java
			CLASSNAME=$(basename "$CLASSNAME" .java)
			echo $CLASSNAME
		}
		check_program javac
		check_program java
		javac -J-Xmx64m -Xlint:deprecation $VPL_SUBFILE0
		if [ "$?" -ne "0" ] ; then
			echo "Not compiled"
			fail_abort
		fi
		MAINCLASS=$(getClassName "$VPL_SUBFILE0")
		if [ "$MAINCLASS" = "" ] ; then
			echo "Class with \"public static void main(String[] arg)\" method not found"
			fail_abort
		fi
		# cat common_script.sh > vpl_execution
		# echo $MAINCLASS >&2
		echo "#!/bin/bash" >> vpl_execution
		echo "java -Xmx16M -enableassertions $MAINCLASS" >> vpl_execution
		;;
	py)
		check_program python
		# Alguns filtros feitos pelo Paulo Pisani
		if python3 verificar_arquivo.py $VPL_SUBFILE0 ; then
        	echo ""
	        echo "Erro ao verificar arquivo." >> vpl_compilation_error.txt
	        exit 0
        fi
        
		echo "#!/bin/bash" >> vpl_execution
		echo "python3 $VPL_SUBFILE0" >> vpl_execution
		;;
	r|R)
		check_program Rscript
		echo "#!/bin/bash" > vpl_execution
		echo "Rscript $VPL_SUBFILE0" >>vpl_execution
		;;
	js)
		check_program Rscript
		echo "#!/bin/bash" > vpl_execution
		echo "node $VPL_SUBFILE0" >>vpl_execution
		;;
*)
        echo "Formato de arquivo desconhecido."
# 		echo "I'm sorry, but I haven't a default action to run these type of submitted files" >&2
		fail_abort
		;;
esac
} || {
    echo "Erro de compilação."
    fail_abort
}

chmod +x vpl_execution