import cv2
import timeit
from openCV_CPU_SegmentAnswers import OpenCV_CPU_SegmentAnswers
from openCV_CPU_SegmentColumns import OpenCV_CPU_SegmentColumns
from openCV_CPU_SegmentLines import OpenCV_CPU_SegmentLines
from openCV_CPU_SegmentSquares import OpenCV_CPU_SegmentSquares
from openCV_GPU_SegmentSquares import OpenCV_GPU_SegmentSquares

# from openCV_CPU_SegmentCircles import OpenCV_CPU_SegmentCircles

TIMES = 1
img = cv2.imread('_testfindSquares_p001_01.png')
img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

cpuSegmentSquares = OpenCV_CPU_SegmentSquares(img)
cpuSegmentColumns = OpenCV_CPU_SegmentColumns(img)
cpuSegmentLines = OpenCV_CPU_SegmentLines(img)
cpuSegmentAnswers = OpenCV_CPU_SegmentAnswers(img)
# cpuSegmentCircles = OpenCV_CPU_SegmentCircles(img)

inicio = timeit.default_timer()
for i in range(1, TIMES):
    cpuSegmentSquares.preProcessingImage()
    cpuSegmentColumns.preProcessingImage()
    cpuSegmentLines.preProcessingImage()
    cpuSegmentAnswers.preProcessingImage()
# cpuSegmentCircles.preProcessingImage()
fim = timeit.default_timer()
print('duracao cpu: %f' % ((fim - inicio) / TIMES))

gpu = OpenCV_GPU_SegmentSquares(img)

inicio = timeit.default_timer()
for i in range(1, TIMES): gpu.preProcessingImage()
fim = timeit.default_timer()
print('duracao gpu: %f' % ((fim - inicio) / TIMES))
