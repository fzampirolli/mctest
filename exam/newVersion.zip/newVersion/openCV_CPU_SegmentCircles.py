#!/usr/bin/ipython
# -*- coding: utf-8 -*-"

from CommonUtils import Utils
from segmentInterface import SegmentInterface

try:
    import cv2
except ImportError:
    print
    "You must have OpenCV installed"

import numpy as np

from skimage.measure import regionprops
from skimage.measure import label

from itertools import combinations

DEBUG = False
circle_min = 400
circle_max = 940  # 895


class OpenCV_CPU_SegmentCircles(SegmentInterface):
    def __init__(self, image):
        self.image = image
        [self.height, self.width] = self.image.shape
        super(OpenCV_CPU_SegmentCircles, self).__init__()

    def preProcessingImage(self):
        img = self.image

        img = cv2.medianBlur(img, 3)
        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 255
        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (19, 19))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        img = cv2.distanceTransform(img, cv2.DIST_L2, 3)

        # label
        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        p = []
        areaMax = 0
        for region in regionprops(labels):
            if areaMax < region.area:
                areaMax = region.area
            # print region.area
            if circle_min < region.area < circle_max:
                h, w = region.centroid
                p.append([int(h), int(w)])

        findRec = []  # se tiver mais que 4 pontos, escolho os que formam um retangulo
        for i in combinations(range(len(p)), 4):
            if Utils.isBigRectangle(p[i[0]], p[i[1]], p[i[2]], p[i[3]]):
                findRec = [p[i[0]], p[i[1]], p[i[2]], p[i[3]]]

        if not findRec:
            print
            "ERRO in get_circles: to not find circles"
            print
            "AREA MAXIMA DO CIRCULO = ", areaMax
            print
            "INTERVALO CONSIDERADO  = ", circle_min, circle_max
            return -1
        else:
            return Utils.order_points(findRec)

        return self.width
