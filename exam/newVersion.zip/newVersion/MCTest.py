#!/usr/bin/ipython
# -*- coding: utf-8 -*-"

from CommonUtils import Utils


def showfig(image, ucmap):
    # para visualizar uma imagem neste ipython notebook
    # nÃ£o funcionado quando uso o shell
    imgplot = plt.imshow(image, ucmap)


# Ã© necessÃ¡rio importar a biblioteca openCV
try:
    import cv2
    # conda install opencv
except ImportError:
    print
    "You must have OpenCV installed"

import csv
import os
import os.path
import glob
import sys
import smtplib
import warnings
import PyPDF2

warnings.filterwarnings("ignore", category=DeprecationWarning)

import numpy as np
import matplotlib.pyplot as plt
# conda install matplotlib

from skimage.measure import regionprops
from skimage.measure import label

# import para ler o cÃ³digo de barras
from sys import platform as _platform

if _platform == "linux" or _platform == "linux2":
    pass

elif _platform == "darwin":
    # import libzbar as zbar # para rodar zbar no mac osx
    print
    "usando mÃ©todo prÃ³prio do zbar"
elif _platform == "win32":
    print
    "testar import para zbar no windows"

DEBUG = False


# comentar esta linha para rodar do shell
# get_ipython().magic(u'matplotlib inline')

class MCTest(object):
    # Classe principal, contendo todos os atributos e mÃ©todos necessÃ¡rios
    filePath = ''  # caminho do arquivo pdf
    fileExt = ['.pdf', '.tiff']  # tipos suportados de "uma imagem com vÃ¡rias pÃ¡ginas"
    typeCorrection = 1  # tipo de correÃ§Ã£o, se =0 entÃ£o nÃ£o tem gabarito
    imageStack = None  # sequencia de n imagens H x W x P x n
    imageSatchLen = 0  # sequencia de n imagens
    imageGS = None  # imagem em nÃ­veis de cinza
    idTest = None  # id do teste definido pelo cÃ³digo de barras
    imgSquares = None  # segmenta define quadros de respostas
    imgSquaresGS = None  # imagem dos quadros de respostas
    imgLins = None  # imagem das linhas do quadro de resposta
    imgCols = None  # imagem das colunas do quadro de resposta
    imgAnswers = None  # imagem segmentada com as respostas
    testAnswars = []  # armazena todas as correÃ§Ãµes
    conteudosStr = []  # armazena todos os assuntos/conteudo de cada questao
    matriculas = []  # armazena todas as matrÃ­culas lidas de *_GAB

    rectSquares = []  # retÃ¢ngulos ordenados dos quadros de respostas
    imgQi = None  # imagem do quadro de respostas i da pÃ¡gina
    imgPers = None  # imagem ajustada para um padrÃ£o 20*W x 20*H
    H = None  # altura da imagem
    W = None  # largura da imagem

    NUM_RESPOSTAS = 0  # nÃºmero de respostas de cada questao
    NUM_QUESTOES = 0  # nÃºmero de questoes do teste
    mr = None  # matriz linhas x colunas de {0,1}
    mg = None  # matriz do gabarito linhas x colunas de {0,1}
    notas = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'O', 'P']
    countPage = 0  # contador de páginas
    countSquare = 0  # contador de quadro de respostas
    heightBarCode = 0  # altura do barcode em imageGS

    def __init__(self, filePath, typeCorrection):  # instancia um objeto/projeto de MCTest
        print
        "MCTest criado"
        self.testAnswars = []
        self.typeCorrection = typeCorrection
        self.filePath = filePath
        self.imageSatchLen = len(Utils.get_images_from_pdf(self.filePath))

    def findSquares(self):
        img = self.imgSquaresGS

        H, W = img.shape

        DEBUG = True

        # blur the image
        # img=cv2.GaussianBlur(img,(3,3),0)
        # binarizacaoo por otsu
        img[:, W - 1] = img[:, 1] = img[1, :] = img[H - 1, :] = 0

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_01.png", img)

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        img0 = img

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_02.png", img)

        # se = cv2.getStructuringElement(cv2.MORPH_CROSS,(3,3)) # retirei para nÃºm./letras
        # img=cv2.morphologyEx(img, cv2.MORPH_DILATE, se)       # grandes!!!

        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_03.png", img)

        # preenche buracos
        img = cv2.distanceTransform(img, cv2.cv.CV_DIST_L2, cv2.cv.CV_DIST_MASK_PRECISE)

        # label
        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        # encontra circulos
        img = np.zeros(img.shape, dtype='uint8')
        for region in regionprops(labels):
            if 200 < region.area < 3500:  # alterei
                # if 250<region.area<900:
                img[labels == region.label] = 255
            else:
                continue

        # encontra quadros
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_04.png", img)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 30))  # ajustar
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_05.png", img - img0)

        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0
        img = cv2.morphologyEx(img, cv2.MORPH_ERODE, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_06.png", img - img0)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 90))  # mudei 3/5/17, antes 120
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_07.png", img - img0)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (80, 1))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_08.png", img - img0)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25))
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_09.png", img - img0)
        b = 5;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0

        self.imgSquares = img

        (contours, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:len(contours)]

        size_rectangle_max = 0
        squares = []
        for cnt in contours:  # loop over the contours
            approximation = cv2.approxPolyDP(cnt, 0.04 * cv2.arcLength(cnt, True), True)

            # has the polygon 4 sides?
            if (not (len(approximation) == 4)):
                continue;
            # is the polygon convex ?
            if (not cv2.isContourConvex(approximation)):
                continue;
                # area of the polygon
            size_rectangle = cv2.contourArea(approximation)

            if size_rectangle > 800:
                cv2.drawContours(self.imgSquares, [approximation], 0, (255, 0, 255), 10)
                squares.append(self.SortPointsExtreme(approximation))

        pt = []
        ptSort = []
        H, W = self.imgSquares.shape
        for i in range(len(squares)):
            squa = squares[i]

            aux = np.array(squa, np.int64)
            y1, x1 = aux[1]
            y2, x2 = aux[3]
            [p1, p2] = [[min(x1, x2), min(y1, y2)], [max(x1, x2), max(y1, y2)]]

            ptSort.append([p1, p2])

            pc = p1[0] / 30 + H * np.int(p1[1] / 30)

            pt.append(pc)

        pto = np.argsort(pt)

        self.rectSquares = []
        for i in range(len(ptSort)):
            self.rectSquares.append(ptSort[pto[i]])

    def setColumns(self):  # count Columns, define automat. o nÃºmero de respostas
        img = self.imgQi[:, :];
        H, W = img.shape

        # blur the image
        # img=cv2.GaussianBlur(img,(3,3),0)

        DEBUG = False

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_01.png", img)

        # binarizaÃ§Ã£o por otsu
        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 255

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        img0 = img

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_02.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, se)

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_03.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_04.png", img)

        # preenche buracos
        img = cv2.distanceTransform(img, cv2.cv.CV_DIST_L2, cv2.cv.CV_DIST_MASK_PRECISE)

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_05.png", img)

        # label
        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_06.png", img)

        # encontra circulos
        img = np.zeros(img.shape, dtype='uint8')
        for region in regionprops(labels):
            if 200 < region.area < 600:  # alterei
                # if 250<region.area<900:
                img[labels == region.label] = 255
            else:
                continue

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_07.png", img)

        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0
        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, se)

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_08.png", img)

        # Morphological Opening
        se = cv2.getStructuringElement(cv2.MORPH_RECT, (1, H / 2))
        # img[:,W-1]=img[:,1]=img[1,:]=img[H-1,:]=0
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite(
            "_testCol" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_09.png", img)

        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0

        self.imgCols = img

        (contours, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:len(contours)]
        self.NUM_RESPOSTAS = len(contours)
        if DEBUG: print
        "NUM_RESPOSTAS=", self.NUM_RESPOSTAS

    def setLines(self):  # count Lines, define automaticamente o nÃºmero de questoes
        img = self.imgQi[:, :];
        H, W = img.shape

        # blur the image
        # img=cv2.GaussianBlur(img,(3,3),0)

        # binarizaÃ§Ã£o por otsu
        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 255

        DEBUG = False

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        img0 = img

        if DEBUG: cv2.imwrite(
            "_testLines" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_01.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, se)

        if DEBUG: cv2.imwrite(
            "_testLines" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_02.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite(
            "_testLines" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_03.png", img)

        # preenche buracos
        img = cv2.distanceTransform(img, cv2.cv.CV_DIST_L2, cv2.cv.CV_DIST_MASK_PRECISE)

        # label
        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        # encontra cÃ­rculos
        img = np.zeros(img.shape, dtype='uint8')
        for region in regionprops(labels):
            if 200 < region.area < 600:  # alterei
                # if 250<region.area<900:
                img[labels == region.label] = 255
            else:
                continue

        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0
        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, se)
        if DEBUG: cv2.imwrite(
            "_testLines" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_04.png", img)

        # Morphological Opening
        se = cv2.getStructuringElement(cv2.MORPH_RECT, (2 * W, 1))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)
        if DEBUG: cv2.imwrite(
            "_testLines" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_05.png", img)

        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0

        se = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        img = cv2.morphologyEx(img, cv2.MORPH_ERODE, se)
        if DEBUG: cv2.imwrite(
            "_testLines" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(self.countSquare + 1) + "_q_06.png", img)

        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0

        self.imgLins = img

        (contours, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:len(contours)]
        self.NUM_QUESTOES = len(contours)
        if DEBUG: print
        "NUM_QUESTOES=", self.NUM_QUESTOES

    def segmentAnswers(self, countPage, countSquare):
        img0 = self.imgQi[:, :]
        H, W = img0.shape

        DEBUG = False

        impath = os.path.abspath(self.filePath) + "_p" + str(countPage + 1).zfill(3) + "_" + str(countSquare + 1)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_01.png", img0)

        img = cv2.GaussianBlur(img0, (9, 9), 0)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_02.png", img)

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_03.png", img)

        img[:, W - 1] = img[:, 1] = img[1, :] = img[H - 1, :] = 0

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        img2 = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_02.png", img2)

        img[:, W - 1] = img[:, 1] = img[1, :] = img[H - 1, :] = 0

        q = 1
        jfim = 0
        jini = 0
        mr = []
        invalida = 0
        while 1:  # para cada linha da imagem
            count = 0
            while jfim < H and self.imgLins[jfim, 5] == 0:
                jfim = jfim + 1
                jini = jfim
            while jfim < H and self.imgLins[jfim, 5]:
                jfim = jfim + 1
            if jfim >= H:
                break
            # print q,j
            ## verifica qual foi a resposta
            im = img2[jini:jfim, :]
            (contours, _) = cv2.findContours(im.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            answers_area = []  # em questões duplicadas, pegar a com maior area
            answers_n = []
            for cnt in contours:  # loop over the contours
                area = cv2.contourArea(cnt)
                if area > 50:
                    count = count + 1
                    x, y, w, h = cv2.boundingRect(cnt)
                    resp = x * self.NUM_RESPOSTAS / (W - 10)
                    n = self.notas[resp]
                    answers_n.append(n)
                    answers_area.append(area)
                    # print self.NUM_RESPOSTAS,W,x,resp,n,count

            if count == 1:  # somente uma marcação ==> OK
                mr.append(n)
            elif count == 0:  # sem marcação ==> questão inválida!
                mr.append(str(
                    count))  # questao invÃ¡lida
                invalida = invalida + 1
            else:  # se mais de uma marcação, analisar pela área desconsiderando as marcações fracas, com área < percOK% da área máxima

                # plt.figure(figsize=(15,15))
                # showfig(im,"gray")
                # print "questÃ£o=",q+1,countSquare,jini,jfim

                percOK = 0.75  # < porcentagem da area maxima sera descartada

                aux = answers_area / np.max(
                    answers_area) * 1.0 < percOK  # verdade para áreas < percOK%, ex. [250 130 230] aux=[False True False]
                aaux = {x: list(aux).count(x) for x in set(list(aux))}  # conta False e True

                if count > 1 and aaux.has_key(
                        False):  # salva somente as questoes com respostas duplicadas = areas > percOK
                    if aaux[False] > 1:  # se tem mais que uma marcação forte > percOK => questão inválida
                        impath = os.path.abspath(self.filePath) + "_p" + str(countPage + 1).zfill(3) + "_" + str(
                            countSquare + 1) + "_q" + str(q).zfill(3) + ".png"
                        if DEBUG:
                            print
                            ">>>INVALIDA: ", impath
                            print
                            ">>>>>>>>>>>>>", answers_area
                            print
                            ">>>>>>>>>>>>>", answers_n

                        cv2.imwrite(impath, img0[jini:jfim, :])

                        mr.append(str(
                            count))  # questao invÃ¡lida
                        invalida = invalida + 1

                    elif aaux.has_key(True) and aaux[
                        False] == 1:  # se tem uma marcacao forte e uma ou mais marcacoes fracas < percOK, desconsidero, pegando somente a mais forte

                        if DEBUG:
                            print
                            ">>>RECONSIDERAMOS: ", impath
                            print
                            ">>>>>>>>>>>>>>>>>>>", answers_area
                            print
                            ">>>>>>>>>>>>>>>>>>>", answers_n
                            print
                            ">>>>>>>>>>>>>>>>>>>", aux, answers_n[list(aux).index(False)]

                        respostaConsiderada = answers_n[
                            list(aux).index(False)]  # pego o conceito com marcacao mais forte > percOK!!!

                        impath = os.path.abspath(self.filePath) + "_p" + str(countPage + 1).zfill(3) + "_" + str(
                            countSquare + 1) + "_q" + str(q).zfill(3) + "_" + respostaConsiderada + "_OK.png"
                        cv2.imwrite(impath, img0[jini:jfim, :])

                        mr.append(respostaConsiderada)
            q = q + 1
            jfim = jfim + 1

        self.testAnswars.append([countPage, self.idTest, countSquare,
                                 self.NUM_RESPOSTAS, self.NUM_QUESTOES, invalida, 0, mr])
        DEBUG = False

    def SortPointsExtreme(self, big_rectangle):  # ordena extremos do quadro
        points2 = np.float32(big_rectangle)

        Haux = (points2[:, :, 1].min() + points2[:, :, 1].max()) / 2
        Waux = (points2[:, :, 0].min() + points2[:, :, 0].max()) / 2
        p0 = p1 = p2 = p3 = []
        for i in range(4):
            if points2[i, 0, 0] < Waux and points2[i, 0, 1] < Haux:
                p0 = points2[i, 0]
            if points2[i, 0, 0] < Waux and points2[i, 0, 1] > Haux:
                p1 = points2[i, 0]
            if points2[i, 0, 0] > Waux and points2[i, 0, 1] > Haux:
                p2 = points2[i, 0]
            if points2[i, 0, 0] > Waux and points2[i, 0, 1] < Haux:
                p3 = points2[i, 0]
        return np.float32([p0, p1, p2, p3])

    def saveCSV(self):  # salva em disco todos os gabaritos e os testes num arquivo csv
        f = self.filePath + '.csv'

        if os.path.exists(f):
            print
            'Arquivo csv ja existe, altere o nome do arquivo pdf ou remove o csv'
            # os.remove(f)
            # print 'arquivo removido!!!'
        else:
            print
            f + ' criado no HD'
            L1 = ["Pag", "ID", "Resp", "Quest", "Inv", "Nota"]

            # L2 = range(1,cor10.NUM_QUESTOES+1)
            with open(f, 'wb') as csvfile:
                spamWriter = csv.writer(csvfile, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
                spamWriter.writerow([','.join([str(x) for x in L1])])  # ,',',','.join([str(x) for x in L2])])

            for i in range(len(self.testAnswars)):
                with open(f, 'a') as csvfile:
                    spamWriter = csv.writer(csvfile, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
                    t = self.testAnswars[i]
                    s = [(',').join(str(x) for x in t[:7]), ',', ','.join(x for x in t[7])]
                    spamWriter.writerow(s)

    def saveCSVone(self):  # salva em disco todos os gabaritos e os testes num arquivo csv
        f = self.filePath + '.csv'

        if True:  # os.path.exists(f):
            # print 'Arquivo csv já existe, altere o nome do arquivo pdf ou remove o csv'
            # os.remove(f)
            # print 'arquivo removido!!!'
            # else:
            print
            f + ' criado no HD'

            with open(f, 'wb') as csvfile:
                L1 = ['Pag', 'ID', 'Resp', 'Quest', 'Inv', 'Nota']
                #                print self.testAnswarsOneLine
                t = self.testAnswarsOneLine[0]
                L1.extend(range(1, t[3] + 1))  # questoes
                if len(t) > 7:
                    L1.extend(range(1, 1 + len(str(t[7]).split(','))))  # indice das questoes sorteadas
                    if self.conteudosStr:
                        L1.extend(x[0] for x in self.conteudosStr)

                spamWriter = csv.writer(csvfile, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
                spamWriter.writerow([','.join([str(x) for x in L1])])

            for i in range(len(self.testAnswarsOneLine)):
                with open(f, 'a') as csvfile:
                    spamWriter = csv.writer(csvfile, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
                    t = self.testAnswarsOneLine[i]

                    s = [(',').join(str(x) for x in t[:6]), ',', ','.join(x for x in t[6])]
                    if self.conteudosStr:  # questÃµes classificadas por assuntos
                        if len(t) == 9:
                            x = ''.join(x for x in t[7])
                            s.append(',')
                            s.append(x)
                            x = ','.join(x for x in t[8])
                            s.append(',')
                            s.append(x)
                    spamWriter.writerow(s)

    def setAnswarsOneLine(self):
        i = 0
        self.testAnswarsOneLine = []
        while i < len(self.testAnswars):
            test = self.testAnswars[i]
            resp = []
            invalida = nota = numquest = 0
            while (i < len(self.testAnswars) and str(test[0]) == str(self.testAnswars[i][0])):
                resp.extend(self.testAnswars[i][7:])
                numquest = numquest + int(self.testAnswars[i][4])
                invalida = invalida + int(self.testAnswars[i][5])
                nota = nota + int(self.testAnswars[i][6])
                i = i + 1

            r = []
            for j in resp:
                r = np.concatenate((r, j), axis=0)

            self.testAnswarsOneLine.append([test[0] + 1, test[1], test[3], numquest, invalida, nota, r])

    def writeCSV(self):  # imprime conteÃºdo do arquivo csv
        print
        self.filePath + '.csv'
        with open(self.filePath + '.csv', 'rb') as f:
            reader = csv.reader(f)
            for row in reader:
                print(','.join(row))

    def sendMail(self):
        mailSend = ''
        msg = "\n"
        with open(self.filePath + '.csv', 'rb') as f:
            mailSend = self.filePath[self.filePath.index('__') + 2:len(self.filePath) - 4]
            reader = csv.reader(f)
            for row in reader:
                msg = msg + ",".join(row) + "\n"

            FROM = "lists.zampirolli@gmail.com"
            TO = [mailSend]  # must be a list
            SUBJECT = "MCTest corrected the file" + self.filePath + ".csv"

            # Prepare actual message                                                                        

            message = """\                                                                                  
            From: %s                                                                                        
            To: %s                                                                                          
            Subject: %s                                                                                     
                                                                                                            
            %s                                                                                              
            """ % (FROM, ", ".join(TO), SUBJECT, msg)

            # Send the mail                                                                                 

            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(FROM, "UFABC2016")
            server.sendmail(FROM, TO, message)
            server.quit()
            print
            "EMail enviado para", mailSend

    def getMatriculas_GAB(self):
        fileStr = self.filePath[:-4] + '_GAB'
        matriculas = []
        if os.path.exists(fileStr):  # se existe arquivo *_GAB, ler matrÃ­culas
            with open(fileStr, 'rb') as f:
                gabarito = csv.reader(f)
                for gabi in gabarito:  # para cada gabarito de um aluno
                    # ler conteÃºdo _GAB formatando
                    strfile, matr, resp, indexQuest, conteu = str(gabi).split(';')
                    matriculas.append(matr.replace(' ', ''))
        self.matriculas = matriculas

    def studentGrade(self):
        if self.typeCorrection == 0:  # nÃ£o serÃ¡ atribuido nota final ao aluno
            print
            "sem nota final do aluno"
        else:
            # print "calculanado nota final do aluno"
            fileStr = self.filePath[:-4] + '_GAB'
            if os.path.exists(fileStr):  # se existe arquivo *_GAB, calcula nota final
                with open(fileStr, 'rb') as f:
                    gabarito = csv.reader(f)

                    for gabi in gabarito:  # para cada gabarito de um aluno
                        # ler conteÃºdo _GAB formatando
                        strfile, matr, resp, indexQuest, conteu = str(gabi).split(';')
                        strfile = strfile.replace(" ", "")
                        strfile = strfile.replace("['", "")
                        matr = matr.replace(" ", "")  # matrÃ­cula
                        resp = resp.replace(" ", "")  # gabarito
                        resp = resp.replace("'", "")
                        resp = resp.replace("\"", "")

                        indexQuest = indexQuest.replace(" ", "")  # indice das questÃµes sorteadas
                        indexQuest = indexQuest.replace("'", "")
                        indexQuest = indexQuest.replace("\"", "")

                        conteu = conteu.replace("\"", "")  # conteÃºdo/assunto da questao
                        conteu = conteu.replace("]'", "]")
                        conteu = conteu.split('],   [')
                        conteudosStr = []
                        for z in conteu:
                            z = z.replace('  [[', '')
                            z = z.replace(']] \']', '')
                            z = z.split(',')
                            contItens = []
                            for zi in z[1:]:
                                zi = zi.replace(" ", "")
                                zi = zi.replace("[", "")
                                zi = zi.replace("]", "")
                                zi = zi.replace("'", "")
                                contItens.append(zi)
                            conteudosStr.append([z[0], contItens])

                        self.conteudosStr = sorted(conteudosStr)  # conteudos e suas questoes
                        # print conteudosStr

                        conteudo = []  # cria uma lista de conteÃºdos, com questoes corretas de cada aluno
                        for i in conteudosStr:
                            conteudo.append([i[0], len(i[1]), 0])  # conteÃºdo, total quest, quest corret
                        # print conteudo

                        for i in self.testAnswarsOneLine:  # para cada pdf corrigido
                            smat = i[1]
                            #                           print smat,matr

                            # print 'MATRÍCULAS=',smat,'===',matr

                            matr = matr.zfill(11)  # sempre considera 11 dígitos
                            smat = smat[0:len(smat)].zfill(11)
                            # print 'MATRÍCULAS=',smat,'*=*',matr

                            if smat == matr:  # se matricula igual
                                #                              print "achou matricula no gab",matr
                                c = 0
                                notaFinal = 0
                                id = self.testAnswarsOneLine.index(i)
                                self.testAnswarsOneLine[id][6] = list(self.testAnswarsOneLine[id][6])
                                g = resp.split(',')
                                for k in i[6]:  # para cada resposta marcado do aluno
                                    gi = g[c]
                                    c += 1
                                    if self.notas[int(gi)] == k:  # nota correta
                                        notaFinal += 1

                                        ki = 0
                                        for k1 in conteudosStr:
                                            for l in k1[1]:
                                                if len(l) and c == int(l):
                                                    conteudo[ki][2] += 1
                                            ki += 1

                                    else:  # nota errada
                                        s = self.testAnswarsOneLine[id][6][c - 1]
                                        self.testAnswarsOneLine[id][6][c - 1] = s + '/' + self.notas[int(gi)]
                                        ri = self.testAnswarsOneLine[id][6][c - 1]

                                self.testAnswarsOneLine[id][5] = notaFinal
                                ki = 0
                                conteudoPerc = []
                                for k in conteudo:
                                    if conteudo[ki][1]:
                                        conteudoPerc.append(str(conteudo[ki][2]) + '/' + str(conteudo[ki][1]))
                                    ki += 1
                                self.testAnswarsOneLine[id].append(indexQuest)  # indice das quest aleatorias
                                self.testAnswarsOneLine[id].append(conteudoPerc)  # conteÃºdo de cada questao

            else:  # nÃ£o existe gabarito no disco e self.typeCorrection != 0
                # entÃ£o considerar a primeira pÃ¡gina do pdf como o gabarito e todas as provas sÃ£o iguais
                # print "g>>",''.join(self.testAnswars[0][7])
                gabi = self.testAnswarsOneLine[0][6]
                for i in self.testAnswarsOneLine:
                    id = self.testAnswarsOneLine.index(i)
                    self.testAnswarsOneLine[id][6] = list(self.testAnswarsOneLine[id][6])
                    if (id != 0):  # nÃ£o Ã© gabarito, entÃ£o corrige teste
                        c = notaFinal = 0
                        for k in i[6]:
                            if gabi[c] == k:  # nota correta
                                notaFinal = notaFinal + 1
                            else:  # nota errada
                                s = self.testAnswarsOneLine[id][6][c]
                                self.testAnswarsOneLine[id][6][c] = s + '/' + gabi[c]
                                # print "nota errada",k,gabi[c],self.testAnswars[id][6][c]
                            c = c + 1
                        self.testAnswarsOneLine[id][5] = notaFinal

    def segmentBarcode(self):
        img = self.imageGS

        DEBUG = False

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_01.png", img)

        img = cv2.GaussianBlur(img, (3, 3), 0)

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_02.png", img)

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_03.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_RECT, (19, 1))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_04.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_RECT, (250, 1))  # fz: melhor método!!
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, se)

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_05.png", img)

        img = cv2.erode(img, None, iterations=10)

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_06.png", img)

        img = cv2.dilate(img, None, iterations=10)

        if DEBUG: cv2.imwrite("_testBarcode" + "_p" + str(self.countPage + 1).zfill(3) + "_07.png", img)

        # find the contours in the thresholded image
        (cnts, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # if no contours were found, return None
        if len(cnts) == 0:
            return None

        # otherwise, sort the contours by area and compute the rotated
        # bounding box of the largest contour
        c = sorted(cnts, key=cv2.contourArea, reverse=True)[0]
        rect = cv2.minAreaRect(c)
        box = np.int0(cv2.cv.BoxPoints(rect))

        # cv2.drawContours(img, [box], -1, (255, 255, 255), 15)

        square = box  # self.SortPointsExtreme(box)
        y1, x1 = square[1]
        y2, x2 = square[3]
        [p1, p2] = [[min(x1, x2), min(y1, y2)], [max(x1, x2), max(y1, y2)]]

        bord = 50
        self.heightBarCode = p2[0] + bord
        H, W = img.shape
        # print "<<<<<<<<<<>>>>>>>>",p1,p2,H,W

        bord = 5
        self.imgBarCode = self.imageGS[p1[0] - bord:p2[0] + bord, p1[1] - bord:p2[1] + bord]

        # print self.imgBarCode.shape

    def corrTests(self, countPage):  # processa/corrige uma pÃ¡gina especÃ­fica countPage
        print
        "\nprocessando pagina ", str(countPage + 1)
        self.countPage = countPage

        DEBUG = False

        try:  # tenta ler pdf
            imgs = Utils.get_images_from_pdf(self.filePath)
            img = 255 - imgs[countPage]
            # img = img[70:,:];  #REMOVER ISSO SE NECESSARIO
            H, W = img.shape
            if (H < W):
                img = np.rot90(img)

            if DEBUG: cv2.imwrite("_test_corrTests" + "_p" + str(self.countPage + 1).zfill(3) + "_01.png", img)

            # padroniza dimensoes da imagem                                                                          
            self.H = 1754;
            self.W = 1350;
            img = cv2.resize(img, (self.W, self.H), interpolation=cv2.INTER_CUBIC)

            if DEBUG: cv2.imwrite("_test_corrTests" + "_p" + str(self.countPage + 1).zfill(3) + "_02.png", img)

        except:
            print
            "ERRO, read pdf - pag" + str(countPage)

        try:  # tenta achar os 4 circulos
            pts = Utils.get_circles(img)
            pts = np.array(pts, np.float32)
            # print pts
            # img = 255 - Utils.imclearborder(255-img,1)

            self.imageGS = Utils.four_point_transform(img, pts)
            # self.imageGS = img[200:700,:]

            # img = self.imageStack[:,:,countPage]
            # self.imageSatchLen = len(imgs)

            if DEBUG: cv2.imwrite("_test_corrTests" + "_p" + str(self.countPage + 1).zfill(3) + "_03.png", img)
        except:
            print
            "ERRO, find 4 circles - pag " + str(countPage)

        # tenta processar codigo de barras
        try:
            self.segmentBarcode()
            # self.idTest = self.fzbar(self.imgBarCode)
            self.idTest = Utils.decode_barcode_img(self.imgBarCode)[:-1]

        except:
            print
            "ERRO, barcode segmentation"
            self.idTest = 0

        if DEBUG: print
        ">>>>>>>heightBarCode=", self.heightBarCode
        self.imgSquaresGS = self.imageGS[130:, :]  # +1 MUITO SENSÍVEL !!!!!!!!!!!!!!!!!!!!

        if DEBUG: cv2.imwrite("_test_corrTests" + "_p" + str(self.countPage + 1).zfill(3) + "_04.png",
                              self.imgSquaresGS)

        if DEBUG: cv2.imwrite("_test_corrTests" + "_p" + str(self.countPage + 1).zfill(3) + "_05.png", self.imgBarCode)
        print
        "Matrícula=", self.idTest

        try:  # tenta achar os quadros de respostas
            self.findSquares()  # acha os quadros de respostas de cada pÃ¡gina
            # print self.rectSquares

            # processa cada quadro da pÃ¡gina
            for countSquare in range(len(self.rectSquares)):
                self.countSquare = countSquare
                p1, p2 = self.rectSquares[countSquare]
                self.imgQi = self.imgSquaresGS[p1[0] - 6:p2[0], p1[1] - 6:p2[1]]  # -6 MUITO SENSÍVEL !!!!!!!!!
                if DEBUG: cv2.imwrite("_test_corrTests" + "_p" + str(self.countPage + 1).zfill(3) + "_q" + str(
                    self.countSquare + 1).zfill(2) + "_06.png", self.imgQi)
                self.setColumns()
                self.setLines()
                self.segmentAnswers(countPage, countSquare)

            self.setAnswarsOneLine()  # deixa as respostas de cada quadro em uma linha
            self.studentGrade()  # calcula nota final do aluno

        except:
            print
            "ERRO, ao achar os quadros de respotas"
            with open(self.filePath + ".csv", 'wb') as csvfile:
                spamWriter = csv.writer(csvfile, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
                spamWriter.writerow("ERRO, ao achar os quadros de respotas - pag " + str(countPage))
            try:
                cv2.imwrite(self.filePath + "_ERRO.png", self.imgSquaresGS)
            except:
                print
                "ERRO, ao gravar imagem"

            sys.exit()


def main(argv):  # cÃ³digo necessÃ¡rio para rodar do shell
    if len(sys.argv) == 1:

        # mypath = ['/srv/ftp/upload/MCTest4/','/home/fz/Dropbox/__MCTest/*/corrections/*/vision/','/home/fz/Dropbox/PI/PI-Presencial/*/script3MCTest/corrections/*/vision/']

        mypath = ['/home/fz/Dropbox/_henriqueMCTest/MCTest5']

        # mypath = '/Users/fz/MCTest/MCTest10/PDFsAvaliacoes/'
        listext = ['*.pdf']

        for myp in mypath:
            try:
                listdir = glob.os.listdir(myp)
            except:
                listdir = glob.glob(myp)

            listdir.append('')

            for dir in listdir:
                for ext in listext:
                    for file in np.sort(glob.glob(myp + dir + '/' + ext)):
                        if not (os.path.exists(file + '.csv')):  # se nao corrigiu
                            try:
                                PyPDF2.PdfFileReader(open(file, "rb"))
                            except PyPDF2.utils.PdfReadError:
                                pass
                            else:

                                print
                                "Criado arquivo " + file + '.csv'
                                c = csv.writer(open(file + '.csv', "wb"))
                                cor = MCTest(file, 1)
                                for i in range(0, cor.imageSatchLen):  # para corrigir todas as pÃ¡ginas do pdf
                                    cor.corrTests(i)
                                cor.saveCSVone()  # salva arquivo CSV
                                cor.writeCSV()  # imprime conteÃºdo do CSV
    #                               cor.sendMail() # envia um email com a correÃ§Ã£o para fzampirolli@gmail.com
    else:
        print
        "Rodar do shell"


if __name__ == '__main__':
    main(sys.argv[1:])
