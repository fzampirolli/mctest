from segmentInterface import SegmentInterface


class OpenCV_GPU_SegmentSquares(SegmentInterface):
    def __init__(self, image):
        self.image = image
        [self.height, self.width] = self.image.shape

        super(OpenCV_GPU_SegmentSquares, self).__init__()

    def preProcessingImage(self):
        return self.width
