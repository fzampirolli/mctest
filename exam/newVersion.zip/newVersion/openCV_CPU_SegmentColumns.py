#!/usr/bin/ipython
# -*- coding: utf-8 -*-"

from segmentInterface import SegmentInterface

try:
    import cv2
except ImportError:
    print
    "You must have OpenCV installed"

import numpy as np

from skimage.measure import regionprops
from skimage.measure import label

DEBUG = False


class OpenCV_CPU_SegmentColumns(SegmentInterface):
    def __init__(self, image):
        self.image = image
        [self.height, self.width] = self.image.shape
        super(OpenCV_CPU_SegmentColumns, self).__init__()

    def preProcessingImage(self):
        img = self.image
        height, width = img.shape

        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 255

        if DEBUG: cv2.imwrite("_testCol_p_q_01.png", img)

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        img0 = img

        if DEBUG: cv2.imwrite("_testCol_p_q_02.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, se)

        if DEBUG: cv2.imwrite("_testCol_p_q_03.png", img)

        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite("_testCol_p_q_04.png", img)

        # preenche buracos
        img = cv2.distanceTransform(img, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)

        if DEBUG: cv2.imwrite("_testCol_p_q_05.png", img)

        # label
        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        if DEBUG: cv2.imwrite("_testCol_p_q_06.png", img)

        # encontra circulos
        img = np.zeros(img.shape, dtype='uint8')
        for region in regionprops(labels):
            if 200 < region.area < 600:  # alterei
                # if 250<region.area<900:
                img[labels == region.label] = 255
            else:
                continue

        if DEBUG: cv2.imwrite("_testCol_p_q_07.png", img)

        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0
        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, se)

        if DEBUG: cv2.imwrite("_testCol_p_q_08.png", img)

        # Morphological Opening
        se = cv2.getStructuringElement(cv2.MORPH_RECT, (1, height / 2))
        # img[:,W-1]=img[:,1]=img[1,:]=img[H-1,:]=0
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        if DEBUG: cv2.imwrite("_testCol_p_q_09.png", img)

        b = 3;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0

        self.imgCols = img

        (_, contours, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:len(contours)]
        self.NUM_RESPOSTAS = len(contours)
        if DEBUG: print
        "NUM_RESPOSTAS=", self.NUM_RESPOSTAS

        return self.width
