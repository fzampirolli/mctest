from abc import abstractmethod


class SegmentInterface(object):
    filePath = ''
    image = None
    height = None
    width = None
    imgQi = None
    imgLins = None
    countPage = 0

    @abstractmethod
    def preProcessingImage(self): pass
