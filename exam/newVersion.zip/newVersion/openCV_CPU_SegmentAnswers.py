# -*- coding: utf-8 -*-"

from segmentInterface import SegmentInterface

try:
    import cv2
except ImportError:
    print
    "You must have OpenCV installed"

import os
import os.path
import numpy as np

DEBUG = False
countPage = 0
countSquare = 0
imgLins = None


class OpenCV_CPU_SegmentAnswers(SegmentInterface):
    def __init__(self, image):
        self.image = image
        [self.height, self.width] = self.image.shape
        super(OpenCV_CPU_SegmentAnswers, self).__init__()

    def preProcessingImage(self):
        img0 = self.image
        height, width = img0.shape

        impath = os.path.abspath(self.filePath) + "_p" + str(countPage + 1).zfill(3) + "_" + str(countSquare + 1)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_01.png", img0)

        img = cv2.GaussianBlur(img0, (9, 9), 0)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_02.png", img)

        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_03.png", img)

        img[:, width - 1] = img[:, 1] = img[1, :] = img[height - 1, :] = 0

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        img2 = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_test_segmentAnswers" + "_p" + str(self.countPage + 1).zfill(3) + "_" + str(
            self.countSquare + 1) + "_q_02.png", img2)

        img[:, width - 1] = img[:, 1] = img[1, :] = img[height - 1, :] = 0

        q = 1
        jfim = 0
        jini = 0
        mr = []
        invalida = 0
        print(q, jfim, jini)
        while 1:  # para cada linha da imagem
            count = 0
            while jfim < height and self.imgLins[jfim, 5] == 0:
                jfim = jfim + 1
                jini = jfim
            while jfim < height and self.imgLins[jfim, 5]:
                jfim = jfim + 1
            if jfim >= height:
                break
            # print q,j
            ## verifica qual foi a resposta
            im = img2[jini:jfim, :]
            (_, contours, _) = cv2.findContours(im.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            answers_area = []  # em questões duplicadas, pegar a com maior area
            answers_n = []
            for cnt in contours:  # loop over the contours
                area = cv2.contourArea(cnt)
                if area > 50:
                    count = count + 1
                    x, y, w, h = cv2.boundingRect(cnt)
                    resp = x * self.NUM_RESPOSTAS / (width - 10)
                    n = self.notas[resp]
                    answers_n.append(n)
                    answers_area.append(area)
            # print self.NUM_RESPOSTAS,W,x,resp,n,count

            if count == 1:  # somente uma marcação ==> OK
                mr.append(n)
            elif count == 0:  # sem marcação ==> questão inválida!
                mr.append(str(
                    count))  # questao invÃ¡lida
                invalida = invalida + 1
            else:  # se mais de uma marcação, analisar pela área desconsiderando as marcações fracas, com área < percOK% da área máxima

                # plt.figure(figsize=(15,15))
                # showfig(im,"gray")
                # print "questÃ£o=",q+1,countSquare,jini,jfim

                percOK = 0.75  # < porcentagem da area maxima sera descartada

                aux = answers_area / np.max(
                    answers_area) * 1.0 < percOK  # verdade para áreas < percOK%, ex. [250 130 230] aux=[False True False]
                aaux = {x: list(aux).count(x) for x in set(list(aux))}  # conta False e True

                if count > 1 and aaux.has_key(
                        False):  # salva somente as questoes com respostas duplicadas = areas > percOK
                    if aaux[False] > 1:  # se tem mais que uma marcação forte > percOK => questão inválida
                        impath = os.path.abspath(self.filePath) + "_p" + str(countPage + 1).zfill(3) + "_" + str(
                            countSquare + 1) + "_q" + str(q).zfill(3) + ".png"
                        if DEBUG:
                            print
                            ">>>INVALIDA: ", impath
                            print
                            ">>>>>>>>>>>>>", answers_area
                            print
                            ">>>>>>>>>>>>>", answers_n

                        cv2.imwrite(impath, img0[jini:jfim, :])

                        mr.append(str(
                            count))  # questao invÃ¡lida
                        invalida = invalida + 1

                    elif aaux.has_key(True) and aaux[
                        False] == 1:  # se tem uma marcacao forte e uma ou mais marcacoes fracas < percOK, desconsidero, pegando somente a mais forte

                        if DEBUG:
                            print
                            ">>>RECONSIDERAMOS: ", impath
                            print
                            ">>>>>>>>>>>>>>>>>>>", answers_area
                            print
                            ">>>>>>>>>>>>>>>>>>>", answers_n
                            print
                            ">>>>>>>>>>>>>>>>>>>", aux, answers_n[list(aux).index(False)]

                        respostaConsiderada = answers_n[
                            list(aux).index(False)]  # pego o conceito com marcacao mais forte > percOK!!!

                        impath = os.path.abspath(self.filePath) + "_p" + str(countPage + 1).zfill(3) + "_" + str(
                            countSquare + 1) + "_q" + str(q).zfill(3) + "_" + respostaConsiderada + "_OK.png"
                        cv2.imwrite(impath, img0[jini:jfim, :])

                        mr.append(respostaConsiderada)
            q = q + 1
            jfim = jfim + 1

        return self.width
