# import libzbar as zbar
import io
import math
import struct
from itertools import combinations

import PyPDF2 as Pypdf
import cv2
import numpy as np
import zbar
from PIL import Image
from skimage.measure import label
from skimage.measure import regionprops

DEBUG = False
circle_min = 400
circle_max = 940  # 895


class Utils(object):
    IMG_DIR = ''

    try:
        CV_CUR_LOAD_IM_GRAY = cv2.CV_LOAD_IMAGE_GRAYSCALE
    except AttributeError:
        CV_CUR_LOAD_IM_GRAY = cv2.IMREAD_GRAYSCALE

    @staticmethod
    def tiff_header_for_ccitt(width, height, img_size, ccitt_group=4):
        tiff_header_struct = '<' + '2s' + 'h' + 'l' + 'h' + 'hhll' * 8 + 'h'
        return struct.pack(tiff_header_struct,
                           b'II',  # Byte order indication: Little indian
                           42,  # Version number (always 42)
                           8,  # Offset to first IFD
                           8,  # Number of tags in IFD
                           256, 4, 1, width,  # ImageWidth, LONG, 1, width
                           257, 4, 1, height,  # ImageLength, LONG, 1, lenght
                           258, 3, 1, 1,  # BitsPerSample, SHORT, 1, 1
                           259, 3, 1, ccitt_group,  # Compression, SHORT, 1, 4 = CCITT Group 4 fax encoding
                           262, 3, 1, 0,  # Threshholding, SHORT, 1, 0 = WhiteIsZero
                           273, 4, 1, struct.calcsize(tiff_header_struct),  # StripOffsets, LONG, 1, len of header
                           278, 4, 1, height,  # RowsPerStrip, LONG, 1, lenght
                           279, 4, 1, img_size,  # StripByteCounts, LONG, 1, size of image
                           0  # last IFD
                           )

    @staticmethod
    def handle_ccitt_fax_decode_img(obj):
        if obj['/DecodeParms']['/K'] == -1:
            ccitt_group = 4
        else:
            ccitt_group = 3
        width = obj['/Width']
        height = obj['/Height']
        data = obj._data  # sorry, getData() does not work for CCITTFaxDecode
        img_size = len(data)
        tiff_header = Utils.tiff_header_for_ccitt(width, height, img_size, ccitt_group)
        data = tiff_header + data
        return cv2.imdecode(np.frombuffer(data, np.uint8), Utils.CV_CUR_LOAD_IM_GRAY)

    @staticmethod
    def handle_other_img(obj):
        data = obj._data
        return 255 - cv2.imdecode(np.frombuffer(data, np.uint8), Utils.CV_CUR_LOAD_IM_GRAY)

    @staticmethod
    def get_img_from_page(pdf_obj, page):
        page_obj = pdf_obj.getPage(page)
        x_obj = page_obj['/Resources']['/XObject'].getObject()
        for obj in x_obj:
            if x_obj[obj]['/Subtype'] == '/Image':
                if x_obj[obj]['/Filter'] == '/CCITTFaxDecode':
                    return Utils.handle_ccitt_fax_decode_img(x_obj[obj])
                else:
                    return Utils.handle_other_img(x_obj[obj])

    @staticmethod
    def get_images_from_pdf(file_path):
        pdf_obj = Pypdf.PdfFileReader(open(file_path, "rb"))
        n_pages = pdf_obj.getNumPages()
        images = [Utils.get_img_from_page(pdf_obj, page) for page in range(n_pages)]
        return images

    @staticmethod
    def get_contour_orientation(contour):
        moments = cv2.moments(contour)
        mu11 = moments['mu11']
        mu02 = moments['mu02']
        mu20 = moments['mu20']
        if (mu20 - mu02) == 0:
            return None
        try:
            angle_rad = 0.5 * math.atan((2 * mu11) / (mu20 - mu02))
            angle_deg = math.degrees(angle_rad)
            return angle_deg
        except:
            print
            contour
            raise

    @staticmethod
    def calc_angle_diff(angle1, angle2):
        diff = abs(angle1 - angle2)
        diff = diff if diff <= 90 else (180.0 - diff)
        return diff

    @staticmethod
    def get_contour_size(contour):
        return cv2.moments(contour)['m00']

    @staticmethod
    def otsu_binary(image):
        # Otsu's thresholding after Gaussian filtering
        blurred = cv2.GaussianBlur(image, (5, 5), 0)
        thresh_val, thresh_img = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return thresh_img

    @staticmethod
    def scharr_gradient(image):
        # compute the Scharr gradient magnitude representation of the images
        # in both the x and y direction
        grad_x = cv2.Scharr(image, ddepth=cv2.CV_32F, dx=1, dy=0)
        grad_y = cv2.Scharr(image, ddepth=cv2.CV_32F, dx=0, dy=1)

        # subtract the y-gradient from the x-gradient
        gradient = cv2.subtract(grad_x, grad_y)
        gradient = cv2.convertScaleAbs(gradient)
        return gradient

    @staticmethod
    def morph_close(image, kernel_size):
        # construct a closing kernel and apply it to the thresholded image
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, kernel_size)
        closed = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)
        return closed

    @staticmethod
    def get_cluster_mean(elements, labels):
        return np.mean(elements)
        # disabled code below used for tests
        if len(elements > 2):
            biggest_cluster = 0
            for i in range(len(labels)):
                if len(elements[labels == i]) > len(elements[labels == biggest_cluster]):
                    biggest_cluster = i
            return np.mean(elements[labels == biggest_cluster])
        else:
            return np.mean(elements)

    @staticmethod
    def extract_rect_img(image, rect):
        width_padding = 50
        box = cv2.boxPoints(rect)
        box = np.int0(box)

        w = rect[1][0]
        h = rect[1][1]

        xs = [i[0] for i in box]
        ys = [i[1] for i in box]
        x1 = min(xs)
        x2 = max(xs)
        y1 = min(ys)
        y2 = max(ys)

        angle = rect[2]
        if angle < -45:
            angle += 90

        # Center of rectangle in source image
        center = ((x1 + x2) / 2, (y1 + y2) / 2)

        # Size of the upright rectangle bounding the rotated rectangle
        size = (x2 - x1 + width_padding, y2 - y1)

        m = cv2.getRotationMatrix2D((size[0] / 2, size[1] / 2), angle, 1.0)

        # Cropped upright rectangle
        cropped = cv2.getRectSubPix(image, size, center)
        cropped = cv2.warpAffine(cropped, m, size)
        cropped_w = h if h > w else w
        cropped_h = h if h < w else w

        # Final cropped & rotated rectangle
        return cv2.getRectSubPix(cropped, (int(cropped_w) + width_padding, int(cropped_h)), (size[0] / 2, size[1] / 2))

    @staticmethod
    def decode_barcode_img(cv2_img):
        rows, cols = cv2_img.shape
        if rows < 1 or cols < 1:
            return None
        try:
            r, png_bytes = cv2.imencode('.png', cv2_img)
            pil_png = Image.open(io.BytesIO(png_bytes)).convert('L')
            width, height = pil_png.size
            png_raw = pil_png.tobytes()  # tostring()
            scanner = zbar.ImageScanner()
            scanner.parse_config('enable')
            image = zbar.Image(width, height, 'Y800', png_raw)
            scanner.scan(image)
            symbols = image.symbols
            for symbol in symbols:
                return symbol.data
            else:
                return None
        except Exception as e:
            print
            e
            return None

    @staticmethod
    def imclearborder(imgBW, radius):
        # fonte: https://www.codementor.io/tips/8240393197/segmenting-license-plate-characters

        # Given a black and white image, first find all of its contours
        imgBWcopy = imgBW.copy()
        (contours, _) = cv2.findContours(imgBWcopy.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

        # Get dimensions of image
        imgRows = imgBW.shape[0]
        imgCols = imgBW.shape[1]

        contourList = []  # ID list of contours that touch the border

        # For each contour...
        for idx in np.arange(len(contours)):
            # Get the i'th contour
            cnt = contours[idx]

            # Look at each point in the contour
            for pt in cnt:
                rowCnt = pt[0][1]
                colCnt = pt[0][0]

                # If this is within the radius of the border
                # this contour goes bye bye!
                check1 = (0 <= rowCnt < radius) or (imgRows - 1 - radius <= rowCnt < imgRows)
                check2 = (0 <= colCnt < radius) or (imgCols - 1 - radius <= colCnt < imgCols)

                if check1 or check2:
                    contourList.append(idx)
                    break

        for idx in contourList:
            cv2.drawContours(imgBWcopy, contours, idx, (0, 0, 0), -1)

        return imgBWcopy

    @staticmethod
    def order_points(pts):
        # fonte: http://www.pyimagesearch.com/2014/08/25/4-point-opencv-getperspective-transform-example/
        rect = np.zeros((4, 2), dtype="int64")
        s = np.sum(pts, axis=1)
        rect[0] = pts[np.argmin(s)]
        rect[2] = pts[np.argmax(s)]
        diff = np.diff(pts, axis=1)
        rect[1] = pts[np.argmin(diff)]
        rect[3] = pts[np.argmax(diff)]
        return rect

    @staticmethod
    def four_point_transform(image, pts):
        # adaptado de: http://www.pyimagesearch.com/2014/08/25/4-point-opencv-getperspective-transform-example/
        rect = pts  # Utils.order_points(pts)
        (tl, tr, br, bl) = rect
        widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
        widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
        maxWidth = max(int(widthA), int(widthB))
        heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
        heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
        maxHeight = max(int(heightA), int(heightB))
        dst = np.array([[0, 0], [maxWidth - 1, 0], [maxWidth - 1, maxHeight - 1], [0, maxHeight - 1]], dtype="float32")
        BORDER = -5
        M = cv2.getPerspectiveTransform(dst, rect)
        M[0, 2] = -pts[0][1] - BORDER
        M[1, 2] = -pts[0][0] - BORDER
        warped = cv2.warpPerspective(image, M, (maxHeight - 2 * BORDER, maxWidth - 2 * BORDER))
        return warped

    @staticmethod
    def isBigRectangle(p1, p2, p3, p4):
        x1, y1 = p1
        x2, y2 = p2
        x3, y3 = p3
        x4, y4 = p4
        cx = (x1 + x2 + x3 + x4) / 4  # centro de massa
        cy = (y1 + y2 + y3 + y4) / 4

        # distancia do centro de massa aos extremos do rectangulo
        dd1 = math.sqrt((cx - x1) ** 2) + math.sqrt((cy - y1) ** 2)
        dd2 = math.sqrt((cx - x2) ** 2) + math.sqrt((cy - y2) ** 2)
        dd3 = math.sqrt((cx - x3) ** 2) + math.sqrt((cy - y3) ** 2)
        dd4 = math.sqrt((cx - x4) ** 2) + math.sqrt((cy - y4) ** 2)
        ddmin = np.mean([dd1, dd2, dd3, dd4])

        erro = max(abs(dd1 - dd2), abs(dd1 - dd3), abs(dd1 - dd4), abs(dd2 - dd3), abs(dd2 - dd4), abs(dd3 - dd4))

        # print "#$#$#$#$#$#$", ddmin, dd1, dd2, dd3, dd4
        # print erro, abs(dd1-dd2), abs(dd1-dd3), abs(dd1-dd4), abs(dd2-dd3), abs(dd2-dd4), abs(dd3-dd4)

        return erro < 50 and ddmin > 500  # > w/2=1350/2

    @staticmethod
    def get_circles(img):
        img = img

        DEBUG = False

        if DEBUG: cv2.imwrite("_testget_circles00.png", img)

        img = cv2.medianBlur(img, 3)

        if DEBUG: cv2.imwrite("_testget_circles01medianBlue5.png", img)

        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 255
        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        if DEBUG: cv2.imwrite("_testget_circles02threshold.png", img)

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (19, 19))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testget_circles03open25.png", img)

        img = cv2.distanceTransform(img, cv2.cv.CV_DIST_L2, 3)

        if DEBUG: cv2.imwrite("_testget_circles04ditance.png", img)

        # label
        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        if DEBUG: cv2.imwrite("_testget_circles05label.png", img)

        # encontra circulos
        # print "in ",circle_min," until ",circle_max," ? "
        p = []
        areaMax = 0
        for region in regionprops(labels):
            if areaMax < region.area:
                areaMax = region.area
            # print region.area
            if circle_min < region.area < circle_max:
                h, w = region.centroid
                p.append([int(h), int(w)])

        # print p
        findRec = []  # se tiver mais que 4 pontos, escolho os que formam um retangulo
        for i in combinations(range(len(p)), 4):
            if Utils.isBigRectangle(p[i[0]], p[i[1]], p[i[2]], p[i[3]]):
                findRec = [p[i[0]], p[i[1]], p[i[2]], p[i[3]]]

        if not findRec:
            print
            "ERRO in get_circles: to not find circles"
            print
            "AREA MAXIMA DO CIRCULO = ", areaMax
            print
            "INTERVALO CONSIDERADO  = ", circle_min, circle_max
            return -1
        else:

            return Utils.order_points(findRec)
