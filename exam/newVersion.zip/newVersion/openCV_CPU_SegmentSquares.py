#!/usr/bin/ipython
# -*- coding: utf-8 -*-"

from segmentInterface import SegmentInterface

try:
    import cv2
except ImportError:
    print
    "You must have OpenCV installed"

import numpy as np

from skimage.measure import regionprops
from skimage.measure import label

DEBUG = False


class OpenCV_CPU_SegmentSquares(SegmentInterface):
    def __init__(self, image):
        self.image = image
        [self.height, self.width] = self.image.shape

        super(OpenCV_CPU_SegmentSquares, self).__init__()

    def preProcessingImage(self):
        img = self.image
        img[:, self.width - 1] = img[:, 1] = img[1, :] = img[self.height - 1, :] = 0
        ret, img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        img0 = img

        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, se)

        img = cv2.distanceTransform(img, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)

        labels = label(img == 0)
        labelCount = np.bincount(labels.ravel())
        background = np.argmax(labelCount)
        img[labels != background] = 255
        labels = label(img)

        # encontra circulos
        img = np.zeros(img.shape, dtype='uint8')
        for region in regionprops(labels):
            if 200 < region.area < 3500:  # alterei
                # if 250<region.area<900:
                img[labels == region.label] = 255
            else:
                continue

        # encontra quadros
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_04.png", img)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 30))  # ajustar
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_05.png", img - img0)

        b = 1;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0
        img = cv2.morphologyEx(img, cv2.MORPH_ERODE, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_06.png", img - img0)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 90))  # mudei 3/5/17, antes 120
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_07.png", img - img0)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (80, 1))
        img = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_08.png", img - img0)

        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25))
        img = cv2.morphologyEx(img, cv2.MORPH_DILATE, kernel)

        if DEBUG: cv2.imwrite("_testfindSquares" + "_p" + str(self.countPage + 1).zfill(3) + "_09.png", img - img0)
        b = 5;
        img[:, -b:] = img[:, :b] = img[:b, :] = img[-b:, :] = 0

        self.imgSquares = img

        # (contours, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        (_, contours, _) = cv2.findContours(img.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:len(contours)]

        size_rectangle_max = 0
        squares = []
        for cnt in contours:  # loop over the contours
            approximation = cv2.approxPolyDP(cnt, 0.04 * cv2.arcLength(cnt, True), True)

            # has the polygon 4 sides?
            if (not (len(approximation) == 4)):
                continue;
            # is the polygon convex ?
            if (not cv2.isContourConvex(approximation)):
                continue;
                # area of the polygon
            size_rectangle = cv2.contourArea(approximation)

            if size_rectangle > 800:
                cv2.drawContours(self.imgSquares, [approximation], 0, (255, 0, 255), 10)
                squares.append(self.SortPointsExtreme(approximation))

            pt = []
            ptSort = []
            H, W = self.imgSquares.shape

            for i in range(len(squares)):
                squa = squares[i]

                aux = np.array(squa, np.int64)
                y1, x1 = aux[1]
                y2, x2 = aux[3]
                [p1, p2] = [[min(x1, x2), min(y1, y2)], [max(x1, x2), max(y1, y2)]]

                ptSort.append([p1, p2])

                pc = p1[0] / 30 + H * np.int(p1[1] / 30)

                pt.append(pc)

            pto = np.argsort(pt)
            self.rectSquares = []

            for i in range(len(ptSort)):
                self.rectSquares.append(ptSort[pto[i]])

        cv2.imwrite("_testfindSquares_10.png", img)
        return self.width

    def SortPointsExtreme(self, big_rectangle):  # ordena extremos do quadro
        points2 = np.float32(big_rectangle)

        Haux = (points2[:, :, 1].min() + points2[:, :, 1].max()) / 2
        Waux = (points2[:, :, 0].min() + points2[:, :, 0].max()) / 2
        p0 = p1 = p2 = p3 = []
        for i in range(4):
            if points2[i, 0, 0] < Waux and points2[i, 0, 1] < Haux:
                p0 = points2[i, 0]
            if points2[i, 0, 0] < Waux and points2[i, 0, 1] > Haux:
                p1 = points2[i, 0]
            if points2[i, 0, 0] > Waux and points2[i, 0, 1] > Haux:
                p2 = points2[i, 0]
            if points2[i, 0, 0] > Waux and points2[i, 0, 1] < Haux:
                p3 = points2[i, 0]
        return np.float32([p0, p1, p2, p3])
